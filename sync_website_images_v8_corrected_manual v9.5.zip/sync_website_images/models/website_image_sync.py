from odoo import models, api

class WebsiteImageSync(models.TransientModel):
    _name = 'website.image.sync'
    _description = 'Sync Unsplash Images Across Websites'

    @api.model
    def sync_unsplash_images(self):
        Website = self.env['website']
        Attachment = self.env['ir.attachment']

        websites = Website.search([])
        all_ids = websites.ids

        for site in websites:
            site_images = Attachment.search([
                ('website_id', '=', site.id),
                ('url', 'ilike', 'unsplash.com'),
                ('mimetype', 'like', 'image%')
            ])

            for img in site_images:
                data = img.datas
                for other_site_id in all_ids:
                    if other_site_id == site.id:
                        continue

                    duplicate = Attachment.search([
                        ('website_id', '=', other_site_id),
                        ('name', '=', img.name)
                    ], limit=1)
                    if duplicate:
                        continue

                    Attachment.create({
                        'name': img.name,
                        'type': 'binary',
                        'datas': data,
                        'res_model': False,
                        'res_id': False,
                        'website_id': other_site_id,
                        'mimetype': img.mimetype,
                        'public': True,
                    })
    