{
    'name': 'Website Image Sync',
    'version': '1.0',
    'summary': 'Sync Unsplash images across Odoo websites',
    'author': 'ChatGPT Assistant',
    'category': 'Website',
    'depends': ['website'],
    'data': [
        'views/website_sync_button.xml',
        'data/ir_cron_sync_images.xml'
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}